<?php
class Pasien_model extends CI_Model {
    public $id;
    public $kode;
    public $nama;
    public $tmp_lahir;
    public $tgl_lahir;
    public $gender;


    public function jeniskelamin(){
        return $this->gender=="L" ? "Laki-Laki" : "Perempuan";
    }
}