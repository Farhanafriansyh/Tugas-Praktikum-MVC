<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h3><b>Form Pendaftaran Pasien</b></h3>
    <table>
        <tr>
            <td>First Name: </td>
            <td><input type="text" name="fname" size="15"></td>
            <td>Last Name: </td>
            <td><input type="text" name="lname" size="15"></td>
        </tr>
        <tr>
            <td>Email: </td>
            <td><input type="text" name="email" size="30" ></td>
        </tr>
        <tr>
            <td>Umur: </td>
            <td><input type="number"></td>
        </tr>
    </table>
    <input type="submit">
</body>
</html>