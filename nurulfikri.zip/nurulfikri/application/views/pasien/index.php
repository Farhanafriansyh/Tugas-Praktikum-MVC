<div class="col-md-12">
    <h3>
        Daftar Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Kode</th>
                <th>Nama</th>
                <th>Tmp_Lahir</th>
                <th>Tgl_Lahir</th>
                <th>Gender</th>
            </tr>
        </thead>
        <tbody>
        <?php 
            $nomor=1;
            foreach($list_pasien as $pasien) {
            echo '
            <tr>
                <td>'.$nomor.'</td>
                <td>'.$pasien->kode.'</td>
                <td>'.$pasien->nama.'</td>
                <td>'.$pasien->tmp_lahir.'</td> 
                <td>'.$pasien->tgl_lahir.'</td>
                <td>'.$pasien->jeniskelamin().'</td>
            </tr>';
            $nomor++;
            }
        ?>
        </tbody>
    </table>
</div>