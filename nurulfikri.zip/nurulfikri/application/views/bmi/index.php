<h1>Data BMI Pasien</h1>

<div class="col-md-12">
    <h3>
        Daftar Pasien
    </h3>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Tinggi</th>
                <th>Berat</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $nomor=1;
            foreach($bt as $b) {
            echo '
            <tr>
                <td>'.$nomor.'</td>
                <td>'.$b->tinggi.'</td>
                <td>'.$b->berat.'</td>
            </tr>';
            $nomor++;
            }
        ?>
        </tbody>
    </table>
</div>