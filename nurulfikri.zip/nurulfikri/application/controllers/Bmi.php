<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bmi extends CI_Controller {
    
	public function index()
	{
		$this->load->model('bmi_model','bmi1');
		$this->bmi1->tinggi=179;
		$this->bmi1->berat=64;

		$this->load->model('bmi_model','bmi2');
		$this->bmi2->tinggi=179;
		$this->bmi1->berat=64;

		$this->load->model('bmi_model','bmi3');
		$this->bmi3->tinggi=179;
		$this->bmi1->berat=64;

		$bt = [$this->bmi1, $this->bmi2, $this->bmi3];
		$data['bt'] = $bt;		
	
		$this->load->view('header');    
		$this->load->view('bmi/index', $data);
		$this->load->view('footer');
	}
}
