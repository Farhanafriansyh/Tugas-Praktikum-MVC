<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Bmi_pasien extends CI_Controller {
    
	public function index()
	{
        $this->load->model('bmipasien_model','bmi_pasien1');
        $this->bmi_pasien1->id=1;
        $this->bmi_pasien1->tanggal='2021 - 04 - 11';
        $this->bmi_pasien1->nama= 'Faiz Fikri';
		$this->bmipasien1->bmi = <?=$list_bmi?>;

		$this->load->view('header');    
		$this->load->view('dashboard/index');
		$this->load->view('footer');
	}
}
