<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pasien extends CI_Controller {
    
	public function index()
	{
		$this->load->model('pasien_model','pasien1');
		$this->pasien1->id=1;
		$this->pasien1->kode='010001';
		$this->pasien1->nama='Faiz Fikri';
		$this->pasien1->tmp_lahir='Jakarta';
		$this->pasien1->tgl_lahir='13 Agustus 2000';
		$this->pasien1->gender='L';

		$this->load->model('pasien_model','pasien2');
		$this->pasien2->id=2;
		$this->pasien2->kode='020001';
		$this->pasien2->nama='Dilan';
		$this->pasien2->tmp_lahir='Bandung';
		$this->pasien2->tgl_lahir='17 Februari 1989';
		$this->pasien2->gender='L';

		$this->load->model('pasien_model','pasien3');
		$this->pasien3->id=3;
		$this->pasien3->kode='030001';
		$this->pasien3->nama='Darman';
		$this->pasien3->tmp_lahir='Papua';
		$this->pasien3->tgl_lahir='25 April 1990';
		$this->pasien3->gender='P';

		$list_pasien = [$this->pasien1, $this->pasien2, $this->pasien3];
		$data['list_pasien']= $list_pasien;
 
		$this->load->view('header');
		$this->load->view('pasien/index',$data);
		$this->load->view('footer');
	}
}
